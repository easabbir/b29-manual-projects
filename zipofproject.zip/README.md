
## 🚀 About Me
I'm a full stack developer...

# b29-manual-projects

This is my manual project where i worked with "Bkash" application and I have written Testcase, test summary report, mindmaps, testplan, bugreport, test matrics and recommendation.

Now I will show how to write a professional readme file
## Documentation

Pls clone this repository to get all the resources.

## FAQ

#### Question 1

Answer 1

#### Question 2

Answer 2


## Screenshots

![App Screenshot](https://via.placeholder.com/468x300?text=App+Screenshot+Here)

